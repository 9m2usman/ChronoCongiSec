--
-- PostgreSQL database dump
--

\restrict FutJcNYUhAnBI2BjnXdrBOUvBdC2RftYhd1HlyA2IW9qcl8QdP6PSbvYMCjYPnk

-- Dumped from database version 16.16
-- Dumped by pg_dump version 16.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: amsc_audit_chain_break(text); Type: FUNCTION; Schema: public; Owner: amsc
--

CREATE FUNCTION public.amsc_audit_chain_break(p_tenant_id text) RETURNS bigint
    LANGUAGE plpgsql STABLE
    AS $$
        DECLARE
            r record;
            expected_seq bigint := 1;
            last_hash text := NULL;
        BEGIN
            FOR r IN SELECT * FROM audit_events WHERE tenant_id = p_tenant_id ORDER BY chain_seq LOOP
                IF r.chain_seq <> expected_seq
                   OR r.prev_hash IS DISTINCT FROM last_hash
                   OR r.event_hash IS DISTINCT FROM amsc_audit_event_hash(
                        r.prev_hash, r.tenant_id, r.id, r.actor_id, r.event_type, r.resource_id,
                        r.action, r.outcome, r.trace_id, r.details_json, r.occurred_at) THEN
                    RETURN expected_seq;
                END IF;
                last_hash := r.event_hash;
                expected_seq := expected_seq + 1;
            END LOOP;
            RETURN NULL;
        END;
        $$;


ALTER FUNCTION public.amsc_audit_chain_break(p_tenant_id text) OWNER TO amsc;

--
-- Name: amsc_audit_event_hash(text, text, text, text, text, text, text, text, text, jsonb, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: amsc
--

CREATE FUNCTION public.amsc_audit_event_hash(prev_hash text, tenant_id text, event_id text, actor_id text, event_type text, resource_id text, action text, outcome text, trace_id text, details jsonb, occurred_at timestamp with time zone) RETURNS text
    LANGUAGE sql STABLE
    AS $$
            SELECT encode(sha256(convert_to(concat_ws(chr(31),
                coalesce(prev_hash, ''), tenant_id, event_id, actor_id, event_type, resource_id,
                action, outcome, coalesce(trace_id, ''), details::text,
                extract(epoch FROM occurred_at)::text
            ), 'UTF8')), 'hex')
        $$;


ALTER FUNCTION public.amsc_audit_event_hash(prev_hash text, tenant_id text, event_id text, actor_id text, event_type text, resource_id text, action text, outcome text, trace_id text, details jsonb, occurred_at timestamp with time zone) OWNER TO amsc;

--
-- Name: amsc_audit_events_chain(); Type: FUNCTION; Schema: public; Owner: amsc
--

CREATE FUNCTION public.amsc_audit_events_chain() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        DECLARE
            last_seq bigint;
            last_hash text;
        BEGIN
            -- One writer per tenant chain at a time (released at commit/rollback).
            PERFORM pg_advisory_xact_lock(hashtextextended('amsc_audit_chain:' || NEW.tenant_id, 0));
            SELECT chain_seq, event_hash INTO last_seq, last_hash
            FROM audit_events WHERE tenant_id = NEW.tenant_id
            ORDER BY chain_seq DESC LIMIT 1;
            NEW.chain_seq := coalesce(last_seq, 0) + 1;
            NEW.prev_hash := last_hash;
            NEW.event_hash := amsc_audit_event_hash(NEW.prev_hash, NEW.tenant_id, NEW.id, NEW.actor_id, NEW.event_type,
                                             NEW.resource_id, NEW.action, NEW.outcome, NEW.trace_id,
                                             NEW.details_json, NEW.occurred_at);
            RETURN NEW;
        END;
        $$;


ALTER FUNCTION public.amsc_audit_events_chain() OWNER TO amsc;

--
-- Name: amsc_audit_protection_report(); Type: FUNCTION; Schema: public; Owner: amsc
--

CREATE FUNCTION public.amsc_audit_protection_report() RETURNS TABLE(check_name text, ok boolean, detail text)
    LANGUAGE plpgsql STABLE
    AS $$
        DECLARE
            trigger_name text;
            enabled text;
            broken text[];
        BEGIN
            FOREACH trigger_name IN ARRAY ARRAY['trg_audit_events_no_update_delete', 'trg_audit_events_no_truncate',
                                        'trg_audit_events_chain', 'trg_forbid_tenant_id_change'] LOOP
                SELECT t.tgenabled::text INTO enabled FROM pg_trigger t
                WHERE t.tgrelid = 'audit_events'::regclass AND t.tgname = trigger_name AND NOT t.tgisinternal;
                check_name := 'trigger ' || trigger_name;
                ok := enabled IS NOT NULL AND enabled <> 'D';
                detail := coalesce('tgenabled=' || enabled, 'missing');
                RETURN NEXT;
            END LOOP;
            SELECT array_agg(tenant_id ORDER BY tenant_id) INTO broken
            FROM (SELECT DISTINCT tenant_id FROM audit_events) t
            WHERE amsc_audit_chain_break(t.tenant_id) IS NOT NULL;
            check_name := 'hash chains intact';
            ok := broken IS NULL;
            detail := CASE WHEN broken IS NULL THEN 'all tenants' ELSE 'broken: ' || array_to_string(broken, ', ') END;
            RETURN NEXT;
        END;
        $$;


ALTER FUNCTION public.amsc_audit_protection_report() OWNER TO amsc;

--
-- Name: amsc_forbid_tenant_id_change(); Type: FUNCTION; Schema: public; Owner: amsc
--

CREATE FUNCTION public.amsc_forbid_tenant_id_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            IF NEW.tenant_id IS DISTINCT FROM OLD.tenant_id THEN
                RAISE EXCEPTION 'tenant_id is immutable on %', TG_TABLE_NAME
                    USING ERRCODE = 'integrity_constraint_violation';
            END IF;
            RETURN NEW;
        END;
        $$;


ALTER FUNCTION public.amsc_forbid_tenant_id_change() OWNER TO amsc;

--
-- Name: amsc_policy_decisions_permanent(); Type: FUNCTION; Schema: public; Owner: amsc
--

CREATE FUNCTION public.amsc_policy_decisions_permanent() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            IF TG_OP = 'DELETE' THEN
                RAISE EXCEPTION 'policy_decisions are permanent; DELETE is forbidden (decision %)', OLD.id
                    USING ERRCODE = '55000';
            END IF;
            IF NEW.id IS DISTINCT FROM OLD.id
               OR NEW.proposal_id IS DISTINCT FROM OLD.proposal_id
               OR NEW.decision IS DISTINCT FROM OLD.decision
               OR NEW.memory_trust IS DISTINCT FROM OLD.memory_trust
               OR NEW.policy_result IS DISTINCT FROM OLD.policy_result
               OR NEW.reasons_json IS DISTINCT FROM OLD.reasons_json
               OR NEW.incident_id IS DISTINCT FROM OLD.incident_id
               OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
                RAISE EXCEPTION 'policy_decisions are permanent; only execution_status may change (decision %)', OLD.id
                    USING ERRCODE = '55000';
            END IF;
            RETURN NEW;
        END;
        $$;


ALTER FUNCTION public.amsc_policy_decisions_permanent() OWNER TO amsc;

--
-- Name: amsc_protect_recovery_snapshot(); Type: FUNCTION; Schema: public; Owner: amsc
--

CREATE FUNCTION public.amsc_protect_recovery_snapshot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            IF TG_OP = 'DELETE' THEN
                IF OLD.pre_recovery_snapshot_sha256 IS NOT NULL THEN
                    RAISE EXCEPTION 'recovery plan % has a captured pre-recovery snapshot and cannot be deleted', OLD.id
                        USING ERRCODE = '55000';
                END IF;
                RETURN OLD;
            END IF;
            IF OLD.pre_recovery_snapshot_sha256 IS NOT NULL AND (
                NEW.pre_recovery_snapshot_json IS DISTINCT FROM OLD.pre_recovery_snapshot_json
                OR NEW.pre_recovery_snapshot_sha256 IS DISTINCT FROM OLD.pre_recovery_snapshot_sha256
            ) THEN
                RAISE EXCEPTION 'pre-recovery snapshot of recovery plan % is immutable', OLD.id
                    USING ERRCODE = '55000';
            END IF;
            RETURN NEW;
        END;
        $$;


ALTER FUNCTION public.amsc_protect_recovery_snapshot() OWNER TO amsc;

--
-- Name: amsc_require_recovery_snapshot(); Type: FUNCTION; Schema: public; Owner: amsc
--

CREATE FUNCTION public.amsc_require_recovery_snapshot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        DECLARE
            snapshot_hash varchar(64);
        BEGIN
            SELECT pre_recovery_snapshot_sha256 INTO snapshot_hash
            FROM recovery_plans WHERE tenant_id = NEW.tenant_id AND id = NEW.plan_id;
            IF FOUND AND snapshot_hash IS NULL THEN
                RAISE EXCEPTION 'recovery action requires a captured pre-recovery snapshot (plan %)', NEW.plan_id
                    USING ERRCODE = '55000';
            END IF;
            RETURN NEW;  -- an unknown plan is rejected by the foreign key
        END;
        $$;


ALTER FUNCTION public.amsc_require_recovery_snapshot() OWNER TO amsc;

--
-- Name: prevent_audit_event_mutation(); Type: FUNCTION; Schema: public; Owner: amsc
--

CREATE FUNCTION public.prevent_audit_event_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            RAISE EXCEPTION 'audit_events is append-only; % is forbidden', TG_OP
                USING ERRCODE = '55000';
        END;
        $$;


ALTER FUNCTION public.prevent_audit_event_mutation() OWNER TO amsc;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_tool_permissions; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.agent_tool_permissions (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    agent_id character varying(36) NOT NULL,
    tool_id character varying(36) NOT NULL,
    allowed_operations character varying(255) DEFAULT '*'::character varying NOT NULL,
    constraints_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.agent_tool_permissions OWNER TO amsc;

--
-- Name: agent_versions; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.agent_versions (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    agent_id character varying(36) NOT NULL,
    version character varying(32) NOT NULL,
    config_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.agent_versions OWNER TO amsc;

--
-- Name: agents; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.agents (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    runtime character varying(64) DEFAULT 'LANGCHAIN'::character varying NOT NULL,
    model character varying(64) DEFAULT 'gpt-4o'::character varying NOT NULL,
    status character varying(32) DEFAULT 'ACTIVE'::character varying NOT NULL,
    config_version character varying(32) DEFAULT 'v1.0.0'::character varying NOT NULL,
    system_prompt text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.agents OWNER TO amsc;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO amsc;

--
-- Name: approvals; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.approvals (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    decision_id character varying(36) NOT NULL,
    approver_user_id character varying(36),
    status character varying(32) DEFAULT 'PENDING'::character varying NOT NULL,
    comments text,
    responded_at timestamp with time zone
);


ALTER TABLE public.approvals OWNER TO amsc;

--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.audit_events (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    actor_id character varying(128) NOT NULL,
    event_type character varying(64) NOT NULL,
    resource_id character varying(128) NOT NULL,
    action character varying(64) NOT NULL,
    outcome character varying(32) NOT NULL,
    trace_id character varying(128),
    details_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    occurred_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    chain_seq bigint NOT NULL,
    prev_hash character varying(64),
    event_hash character varying(64) NOT NULL,
    CONSTRAINT ck_audit_events_chain_link CHECK ((((chain_seq = 1) AND (prev_hash IS NULL)) OR ((chain_seq > 1) AND (prev_hash IS NOT NULL))))
);


ALTER TABLE public.audit_events OWNER TO amsc;

--
-- Name: branches; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.branches (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    code character varying(32) NOT NULL,
    status character varying(32) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.branches OWNER TO amsc;

--
-- Name: checkpoint_items; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.checkpoint_items (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    checkpoint_id character varying(36) NOT NULL,
    record_id character varying(36) NOT NULL,
    version_id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL
);


ALTER TABLE public.checkpoint_items OWNER TO amsc;

--
-- Name: checkpoints; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.checkpoints (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    agent_id character varying(36),
    name character varying(255) NOT NULL,
    integrity_hash character varying(64) NOT NULL,
    record_count integer DEFAULT 0 NOT NULL,
    snapshot_data_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.checkpoints OWNER TO amsc;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.documents (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    source_id character varying(36) NOT NULL,
    title character varying(255) NOT NULL,
    content_ref character varying(1024),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.documents OWNER TO amsc;

--
-- Name: drift_observations; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.drift_observations (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    record_id character varying(36) NOT NULL,
    classification character varying(64) DEFAULT 'POTENTIAL_POISONING'::character varying NOT NULL,
    divergence_score character varying(32) DEFAULT '0.78'::character varying NOT NULL,
    evidence_summary text NOT NULL,
    reviewer_status character varying(32) DEFAULT 'PENDING'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.drift_observations OWNER TO amsc;

--
-- Name: incident_evidence; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.incident_evidence (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    incident_id character varying(36) NOT NULL,
    evidence_type character varying(64) NOT NULL,
    resource_id character varying(128) NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.incident_evidence OWNER TO amsc;

--
-- Name: incidents; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.incidents (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    title character varying(255) NOT NULL,
    classification character varying(64) NOT NULL,
    severity character varying(32) DEFAULT 'HIGH'::character varying NOT NULL,
    status character varying(32) DEFAULT 'OPEN'::character varying NOT NULL,
    affected_record_id character varying(36),
    agent_id character varying(36),
    evidence_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.incidents OWNER TO amsc;

--
-- Name: knowledge_entities; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.knowledge_entities (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    label character varying(255) NOT NULL,
    entity_type character varying(64) DEFAULT 'CONCEPT'::character varying NOT NULL,
    properties_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.knowledge_entities OWNER TO amsc;

--
-- Name: knowledge_relations; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.knowledge_relations (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    source_entity_id character varying(36) NOT NULL,
    target_entity_id character varying(36) NOT NULL,
    relation_type character varying(64) DEFAULT 'REFERENCES'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.knowledge_relations OWNER TO amsc;

--
-- Name: memberships; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.memberships (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    role character varying(64) DEFAULT 'SECURITY_ANALYST'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status character varying(32) DEFAULT 'ACTIVE'::character varying NOT NULL,
    CONSTRAINT ck_memberships_status CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'INACTIVE'::character varying, 'SUSPENDED'::character varying, 'REVOKED'::character varying])::text[])))
);


ALTER TABLE public.memberships OWNER TO amsc;

--
-- Name: memory_records; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.memory_records (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    agent_id character varying(36),
    source_id character varying(36),
    record_type character varying(64) DEFAULT 'KNOWLEDGE'::character varying NOT NULL,
    trust_state character varying(32) DEFAULT 'UNVERIFIED'::character varying NOT NULL,
    current_version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.memory_records OWNER TO amsc;

--
-- Name: memory_versions; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.memory_versions (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    record_id character varying(36) NOT NULL,
    version integer NOT NULL,
    content text NOT NULL,
    checksum character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.memory_versions OWNER TO amsc;

--
-- Name: outbox_events; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.outbox_events (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    event_type character varying(64) NOT NULL,
    payload jsonb NOT NULL,
    status character varying(32) DEFAULT 'PENDING'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    published_at timestamp with time zone
);


ALTER TABLE public.outbox_events OWNER TO amsc;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.permissions (
    id character varying(36) NOT NULL,
    key character varying(64) NOT NULL,
    description text
);


ALTER TABLE public.permissions OWNER TO amsc;

--
-- Name: policy_decisions; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.policy_decisions (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    proposal_id character varying(36) NOT NULL,
    decision character varying(32) NOT NULL,
    memory_trust character varying(32) NOT NULL,
    policy_result character varying(32) NOT NULL,
    reasons_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    incident_id character varying(36),
    execution_status character varying(32) DEFAULT 'NOT_EXECUTED'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.policy_decisions OWNER TO amsc;

--
-- Name: provenance_edges; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.provenance_edges (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    from_record_id character varying(36) NOT NULL,
    to_record_id character varying(36) NOT NULL,
    relation_type character varying(64) DEFAULT 'DERIVED_FROM'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_provenance_edges_no_self_loop CHECK (((from_record_id)::text <> (to_record_id)::text)),
    CONSTRAINT ck_provenance_edges_relation_type CHECK (((relation_type)::text = ANY ((ARRAY['DERIVED_FROM'::character varying, 'TRANSFORMED_INTO'::character varying, 'SUPERSEDES'::character varying])::text[])))
);


ALTER TABLE public.provenance_edges OWNER TO amsc;

--
-- Name: quarantines; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.quarantines (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    record_id character varying(36) NOT NULL,
    incident_id character varying(36),
    reason text NOT NULL,
    quarantined_by character varying(128) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.quarantines OWNER TO amsc;

--
-- Name: recovery_actions; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.recovery_actions (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    plan_id character varying(36) NOT NULL,
    resource_id character varying(128) NOT NULL,
    action_taken character varying(64) NOT NULL,
    outcome character varying(32) DEFAULT 'SUCCESS'::character varying NOT NULL
);


ALTER TABLE public.recovery_actions OWNER TO amsc;

--
-- Name: recovery_plans; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.recovery_plans (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    incident_id character varying(36),
    checkpoint_id character varying(36) NOT NULL,
    target_record_id character varying(36),
    status character varying(32) DEFAULT 'PENDING'::character varying NOT NULL,
    pre_recovery_snapshot_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    impact_preview_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    executed_at timestamp with time zone,
    pre_recovery_snapshot_sha256 character varying(64),
    CONSTRAINT ck_recovery_plans_executed_requires_snapshot CHECK (((executed_at IS NULL) OR (pre_recovery_snapshot_sha256 IS NOT NULL))),
    CONSTRAINT ck_recovery_plans_snapshot_hash_consistent CHECK ((((pre_recovery_snapshot_json = '{}'::jsonb) AND (pre_recovery_snapshot_sha256 IS NULL)) OR ((pre_recovery_snapshot_json <> '{}'::jsonb) AND (pre_recovery_snapshot_sha256 IS NOT NULL) AND ((pre_recovery_snapshot_sha256)::text = encode(sha256(convert_to((pre_recovery_snapshot_json)::text, 'UTF8'::name)), 'hex'::text)))))
);


ALTER TABLE public.recovery_plans OWNER TO amsc;

--
-- Name: retrieval_events; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.retrieval_events (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    agent_id character varying(36) NOT NULL,
    record_id character varying(36) NOT NULL,
    trace_id character varying(128) NOT NULL,
    query_text text,
    occurred_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.retrieval_events OWNER TO amsc;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.role_permissions (
    role_id character varying(36) NOT NULL,
    permission_id character varying(36) NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO amsc;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.roles (
    id character varying(36) NOT NULL,
    tenant_id character varying(36),
    name character varying(64) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.roles OWNER TO amsc;

--
-- Name: sources; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.sources (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    source_type character varying(64) DEFAULT 'DOCUMENT_FEED'::character varying NOT NULL,
    uri character varying(1024),
    trust_state character varying(32) DEFAULT 'UNVERIFIED'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status character varying(32) DEFAULT 'ACTIVE'::character varying NOT NULL,
    CONSTRAINT ck_sources_status CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'INACTIVE'::character varying])::text[])))
);


ALTER TABLE public.sources OWNER TO amsc;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.tenants (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(64) NOT NULL,
    status character varying(32) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.tenants OWNER TO amsc;

--
-- Name: tool_executions; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.tool_executions (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    proposal_id character varying(36) NOT NULL,
    decision_id character varying(36) NOT NULL,
    status character varying(32) DEFAULT 'SUCCESS'::character varying NOT NULL,
    status_code integer DEFAULT 200 NOT NULL,
    result_payload_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    duration_ms integer DEFAULT 0 NOT NULL,
    executed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.tool_executions OWNER TO amsc;

--
-- Name: tool_proposals; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.tool_proposals (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    agent_id character varying(36) NOT NULL,
    action_id character varying(128) NOT NULL,
    tool_name character varying(128) NOT NULL,
    operation character varying(128) NOT NULL,
    parameters_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    memory_refs_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    idempotency_key character varying(255) NOT NULL,
    trace_id character varying(128) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.tool_proposals OWNER TO amsc;

--
-- Name: tool_registrations; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.tool_registrations (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    adapter_type character varying(64) DEFAULT 'SANDBOX_REST'::character varying NOT NULL,
    description text,
    is_protected boolean DEFAULT true NOT NULL,
    schema_definition jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.tool_registrations OWNER TO amsc;

--
-- Name: trace_spans; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.trace_spans (
    id character varying(128) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    trace_id character varying(128) NOT NULL,
    parent_span_id character varying(128),
    operation character varying(128) NOT NULL,
    duration_ms integer DEFAULT 0 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.trace_spans OWNER TO amsc;

--
-- Name: traces; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.traces (
    id character varying(128) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    agent_id character varying(36),
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status character varying(32) DEFAULT 'COMPLETED'::character varying NOT NULL
);


ALTER TABLE public.traces OWNER TO amsc;

--
-- Name: transformations; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.transformations (
    id character varying(36) NOT NULL,
    tenant_id character varying(36) NOT NULL,
    input_record_id character varying(36) NOT NULL,
    output_record_id character varying(36) NOT NULL,
    operation character varying(64) NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.transformations OWNER TO amsc;

--
-- Name: users; Type: TABLE; Schema: public; Owner: amsc
--

CREATE TABLE public.users (
    id character varying(36) NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    status character varying(32) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.users OWNER TO amsc;

--
-- Data for Name: agent_tool_permissions; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.agent_tool_permissions (id, tenant_id, agent_id, tool_id, allowed_operations, constraints_json, created_at) FROM stdin;
\.


--
-- Data for Name: agent_versions; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.agent_versions (id, tenant_id, agent_id, version, config_payload, created_at) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.agents (id, tenant_id, name, runtime, model, status, config_version, system_prompt, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.alembic_version (version_num) FROM stdin;
0009
\.


--
-- Data for Name: approvals; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.approvals (id, tenant_id, decision_id, approver_user_id, status, comments, responded_at) FROM stdin;
\.


--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.audit_events (id, tenant_id, actor_id, event_type, resource_id, action, outcome, trace_id, details_json, occurred_at, chain_seq, prev_hash, event_hash) FROM stdin;
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.branches (id, tenant_id, name, code, status, created_at) FROM stdin;
\.


--
-- Data for Name: checkpoint_items; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.checkpoint_items (id, tenant_id, checkpoint_id, record_id, version_id, checksum) FROM stdin;
\.


--
-- Data for Name: checkpoints; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.checkpoints (id, tenant_id, agent_id, name, integrity_hash, record_count, snapshot_data_json, created_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.documents (id, tenant_id, source_id, title, content_ref, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: drift_observations; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.drift_observations (id, tenant_id, record_id, classification, divergence_score, evidence_summary, reviewer_status, created_at) FROM stdin;
\.


--
-- Data for Name: incident_evidence; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.incident_evidence (id, tenant_id, incident_id, evidence_type, resource_id, metadata) FROM stdin;
\.


--
-- Data for Name: incidents; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.incidents (id, tenant_id, title, classification, severity, status, affected_record_id, agent_id, evidence_json, created_at) FROM stdin;
\.


--
-- Data for Name: knowledge_entities; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.knowledge_entities (id, tenant_id, label, entity_type, properties_json, created_at) FROM stdin;
\.


--
-- Data for Name: knowledge_relations; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.knowledge_relations (id, tenant_id, source_entity_id, target_entity_id, relation_type, created_at) FROM stdin;
\.


--
-- Data for Name: memberships; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.memberships (id, tenant_id, user_id, role, created_at, status) FROM stdin;
\.


--
-- Data for Name: memory_records; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.memory_records (id, tenant_id, agent_id, source_id, record_type, trust_state, current_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: memory_versions; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.memory_versions (id, tenant_id, record_id, version, content, checksum, created_at) FROM stdin;
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.outbox_events (id, tenant_id, event_type, payload, status, created_at, published_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.permissions (id, key, description) FROM stdin;
\.


--
-- Data for Name: policy_decisions; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.policy_decisions (id, tenant_id, proposal_id, decision, memory_trust, policy_result, reasons_json, incident_id, execution_status, created_at) FROM stdin;
\.


--
-- Data for Name: provenance_edges; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.provenance_edges (id, tenant_id, from_record_id, to_record_id, relation_type, created_at) FROM stdin;
\.


--
-- Data for Name: quarantines; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.quarantines (id, tenant_id, record_id, incident_id, reason, quarantined_by, created_at) FROM stdin;
\.


--
-- Data for Name: recovery_actions; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.recovery_actions (id, tenant_id, plan_id, resource_id, action_taken, outcome) FROM stdin;
\.


--
-- Data for Name: recovery_plans; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.recovery_plans (id, tenant_id, incident_id, checkpoint_id, target_record_id, status, pre_recovery_snapshot_json, impact_preview_json, executed_at, pre_recovery_snapshot_sha256) FROM stdin;
\.


--
-- Data for Name: retrieval_events; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.retrieval_events (id, tenant_id, agent_id, record_id, trace_id, query_text, occurred_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.roles (id, tenant_id, name, description, created_at) FROM stdin;
\.


--
-- Data for Name: sources; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.sources (id, tenant_id, name, source_type, uri, trust_state, created_at, status) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.tenants (id, name, slug, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tool_executions; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.tool_executions (id, tenant_id, proposal_id, decision_id, status, status_code, result_payload_json, duration_ms, executed_at) FROM stdin;
\.


--
-- Data for Name: tool_proposals; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.tool_proposals (id, tenant_id, agent_id, action_id, tool_name, operation, parameters_json, memory_refs_json, idempotency_key, trace_id, created_at) FROM stdin;
\.


--
-- Data for Name: tool_registrations; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.tool_registrations (id, tenant_id, name, adapter_type, description, is_protected, schema_definition, created_at) FROM stdin;
\.


--
-- Data for Name: trace_spans; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.trace_spans (id, tenant_id, trace_id, parent_span_id, operation, duration_ms, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: traces; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.traces (id, tenant_id, agent_id, started_at, status) FROM stdin;
\.


--
-- Data for Name: transformations; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.transformations (id, tenant_id, input_record_id, output_record_id, operation, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: amsc
--

COPY public.users (id, email, hashed_password, full_name, status, created_at) FROM stdin;
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: agent_tool_permissions pk_agent_tool_permissions; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.agent_tool_permissions
    ADD CONSTRAINT pk_agent_tool_permissions PRIMARY KEY (id);


--
-- Name: agent_versions pk_agent_versions; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.agent_versions
    ADD CONSTRAINT pk_agent_versions PRIMARY KEY (id);


--
-- Name: agents pk_agents; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT pk_agents PRIMARY KEY (id);


--
-- Name: approvals pk_approvals; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT pk_approvals PRIMARY KEY (id);


--
-- Name: audit_events pk_audit_events; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT pk_audit_events PRIMARY KEY (id);


--
-- Name: branches pk_branches; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT pk_branches PRIMARY KEY (id);


--
-- Name: checkpoint_items pk_checkpoint_items; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.checkpoint_items
    ADD CONSTRAINT pk_checkpoint_items PRIMARY KEY (id);


--
-- Name: checkpoints pk_checkpoints; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.checkpoints
    ADD CONSTRAINT pk_checkpoints PRIMARY KEY (id);


--
-- Name: documents pk_documents; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT pk_documents PRIMARY KEY (id);


--
-- Name: drift_observations pk_drift_observations; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.drift_observations
    ADD CONSTRAINT pk_drift_observations PRIMARY KEY (id);


--
-- Name: incident_evidence pk_incident_evidence; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.incident_evidence
    ADD CONSTRAINT pk_incident_evidence PRIMARY KEY (id);


--
-- Name: incidents pk_incidents; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT pk_incidents PRIMARY KEY (id);


--
-- Name: knowledge_entities pk_knowledge_entities; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.knowledge_entities
    ADD CONSTRAINT pk_knowledge_entities PRIMARY KEY (id);


--
-- Name: knowledge_relations pk_knowledge_relations; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.knowledge_relations
    ADD CONSTRAINT pk_knowledge_relations PRIMARY KEY (id);


--
-- Name: memberships pk_memberships; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT pk_memberships PRIMARY KEY (id);


--
-- Name: memory_records pk_memory_records; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memory_records
    ADD CONSTRAINT pk_memory_records PRIMARY KEY (id);


--
-- Name: memory_versions pk_memory_versions; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memory_versions
    ADD CONSTRAINT pk_memory_versions PRIMARY KEY (id);


--
-- Name: outbox_events pk_outbox_events; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.outbox_events
    ADD CONSTRAINT pk_outbox_events PRIMARY KEY (id);


--
-- Name: permissions pk_permissions; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT pk_permissions PRIMARY KEY (id);


--
-- Name: policy_decisions pk_policy_decisions; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.policy_decisions
    ADD CONSTRAINT pk_policy_decisions PRIMARY KEY (id);


--
-- Name: provenance_edges pk_provenance_edges; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.provenance_edges
    ADD CONSTRAINT pk_provenance_edges PRIMARY KEY (id);


--
-- Name: quarantines pk_quarantines; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.quarantines
    ADD CONSTRAINT pk_quarantines PRIMARY KEY (id);


--
-- Name: recovery_actions pk_recovery_actions; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.recovery_actions
    ADD CONSTRAINT pk_recovery_actions PRIMARY KEY (id);


--
-- Name: recovery_plans pk_recovery_plans; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.recovery_plans
    ADD CONSTRAINT pk_recovery_plans PRIMARY KEY (id);


--
-- Name: retrieval_events pk_retrieval_events; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.retrieval_events
    ADD CONSTRAINT pk_retrieval_events PRIMARY KEY (id);


--
-- Name: role_permissions pk_role_permissions; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT pk_role_permissions PRIMARY KEY (role_id, permission_id);


--
-- Name: roles pk_roles; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT pk_roles PRIMARY KEY (id);


--
-- Name: sources pk_sources; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT pk_sources PRIMARY KEY (id);


--
-- Name: tenants pk_tenants; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT pk_tenants PRIMARY KEY (id);


--
-- Name: tool_executions pk_tool_executions; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_executions
    ADD CONSTRAINT pk_tool_executions PRIMARY KEY (id);


--
-- Name: tool_proposals pk_tool_proposals; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_proposals
    ADD CONSTRAINT pk_tool_proposals PRIMARY KEY (id);


--
-- Name: tool_registrations pk_tool_registrations; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_registrations
    ADD CONSTRAINT pk_tool_registrations PRIMARY KEY (id);


--
-- Name: trace_spans pk_trace_spans; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.trace_spans
    ADD CONSTRAINT pk_trace_spans PRIMARY KEY (id);


--
-- Name: traces pk_traces; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.traces
    ADD CONSTRAINT pk_traces PRIMARY KEY (id);


--
-- Name: transformations pk_transformations; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.transformations
    ADD CONSTRAINT pk_transformations PRIMARY KEY (id);


--
-- Name: users pk_users; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT pk_users PRIMARY KEY (id);


--
-- Name: agent_tool_permissions uq_agent_tool_perm; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.agent_tool_permissions
    ADD CONSTRAINT uq_agent_tool_perm UNIQUE (agent_id, tool_id);


--
-- Name: agent_versions uq_agent_version; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.agent_versions
    ADD CONSTRAINT uq_agent_version UNIQUE (agent_id, version);


--
-- Name: agents uq_agents_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT uq_agents_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: audit_events uq_audit_events_tenant_id_chain_seq; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT uq_audit_events_tenant_id_chain_seq UNIQUE (tenant_id, chain_seq);


--
-- Name: checkpoint_items uq_checkpoint_items_tenant_id_checkpoint_id_record_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.checkpoint_items
    ADD CONSTRAINT uq_checkpoint_items_tenant_id_checkpoint_id_record_id UNIQUE (tenant_id, checkpoint_id, record_id);


--
-- Name: checkpoints uq_checkpoints_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.checkpoints
    ADD CONSTRAINT uq_checkpoints_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: incidents uq_incidents_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT uq_incidents_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: knowledge_entities uq_knowledge_entities_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.knowledge_entities
    ADD CONSTRAINT uq_knowledge_entities_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: memory_records uq_memory_records_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memory_records
    ADD CONSTRAINT uq_memory_records_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: memory_versions uq_memory_versions_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memory_versions
    ADD CONSTRAINT uq_memory_versions_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: memory_versions uq_memory_versions_tenant_record_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memory_versions
    ADD CONSTRAINT uq_memory_versions_tenant_record_id UNIQUE (tenant_id, record_id, id);


--
-- Name: permissions uq_permissions_key; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT uq_permissions_key UNIQUE (key);


--
-- Name: policy_decisions uq_policy_decisions_proposal_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.policy_decisions
    ADD CONSTRAINT uq_policy_decisions_proposal_id UNIQUE (proposal_id);


--
-- Name: policy_decisions uq_policy_decisions_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.policy_decisions
    ADD CONSTRAINT uq_policy_decisions_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: policy_decisions uq_policy_decisions_tenant_id_proposal_id_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.policy_decisions
    ADD CONSTRAINT uq_policy_decisions_tenant_id_proposal_id_id UNIQUE (tenant_id, proposal_id, id);


--
-- Name: provenance_edges uq_provenance_edges_tenant_from_to_relation; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.provenance_edges
    ADD CONSTRAINT uq_provenance_edges_tenant_from_to_relation UNIQUE (tenant_id, from_record_id, to_record_id, relation_type);


--
-- Name: memory_versions uq_record_version; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memory_versions
    ADD CONSTRAINT uq_record_version UNIQUE (record_id, version);


--
-- Name: recovery_plans uq_recovery_plans_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.recovery_plans
    ADD CONSTRAINT uq_recovery_plans_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: sources uq_sources_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT uq_sources_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: branches uq_tenant_branch_code; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT uq_tenant_branch_code UNIQUE (tenant_id, code);


--
-- Name: tool_proposals uq_tenant_idemp_key; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_proposals
    ADD CONSTRAINT uq_tenant_idemp_key UNIQUE (tenant_id, idempotency_key);


--
-- Name: tool_registrations uq_tenant_tool_name; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_registrations
    ADD CONSTRAINT uq_tenant_tool_name UNIQUE (tenant_id, name);


--
-- Name: memberships uq_tenant_user; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT uq_tenant_user UNIQUE (tenant_id, user_id);


--
-- Name: tenants uq_tenants_slug; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT uq_tenants_slug UNIQUE (slug);


--
-- Name: tool_executions uq_tool_executions_proposal_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_executions
    ADD CONSTRAINT uq_tool_executions_proposal_id UNIQUE (proposal_id);


--
-- Name: tool_proposals uq_tool_proposals_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_proposals
    ADD CONSTRAINT uq_tool_proposals_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: tool_registrations uq_tool_registrations_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_registrations
    ADD CONSTRAINT uq_tool_registrations_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: traces uq_traces_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.traces
    ADD CONSTRAINT uq_traces_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: users uq_users_email; Type: CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uq_users_email UNIQUE (email);


--
-- Name: idx_agents_tenant; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX idx_agents_tenant ON public.agents USING btree (tenant_id);


--
-- Name: idx_audit_tenant_occurred; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX idx_audit_tenant_occurred ON public.audit_events USING btree (tenant_id, occurred_at DESC);


--
-- Name: idx_branches_tenant; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX idx_branches_tenant ON public.branches USING btree (tenant_id);


--
-- Name: idx_memberships_tenant_user; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX idx_memberships_tenant_user ON public.memberships USING btree (tenant_id, user_id);


--
-- Name: idx_memory_records_tenant_trust; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX idx_memory_records_tenant_trust ON public.memory_records USING btree (tenant_id, trust_state);


--
-- Name: idx_memory_versions_checksum; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX idx_memory_versions_checksum ON public.memory_versions USING btree (checksum);


--
-- Name: idx_outbox_pending; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX idx_outbox_pending ON public.outbox_events USING btree (status, created_at);


--
-- Name: idx_provenance_from; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX idx_provenance_from ON public.provenance_edges USING btree (tenant_id, from_record_id);


--
-- Name: idx_provenance_to; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX idx_provenance_to ON public.provenance_edges USING btree (tenant_id, to_record_id);


--
-- Name: idx_retrieval_trace; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX idx_retrieval_trace ON public.retrieval_events USING btree (tenant_id, trace_id);


--
-- Name: idx_tenants_slug; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX idx_tenants_slug ON public.tenants USING btree (slug);


--
-- Name: idx_tool_proposals_trace; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX idx_tool_proposals_trace ON public.tool_proposals USING btree (tenant_id, trace_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: ix_agent_tool_permissions_tenant_id_agent_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_agent_tool_permissions_tenant_id_agent_id ON public.agent_tool_permissions USING btree (tenant_id, agent_id);


--
-- Name: ix_agent_tool_permissions_tenant_id_tool_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_agent_tool_permissions_tenant_id_tool_id ON public.agent_tool_permissions USING btree (tenant_id, tool_id);


--
-- Name: ix_agent_versions_tenant_id_agent_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_agent_versions_tenant_id_agent_id ON public.agent_versions USING btree (tenant_id, agent_id);


--
-- Name: ix_approvals_tenant_id_approver_user_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_approvals_tenant_id_approver_user_id ON public.approvals USING btree (tenant_id, approver_user_id);


--
-- Name: ix_approvals_tenant_id_decision_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_approvals_tenant_id_decision_id ON public.approvals USING btree (tenant_id, decision_id);


--
-- Name: ix_checkpoint_items_tenant_id_checkpoint_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_checkpoint_items_tenant_id_checkpoint_id ON public.checkpoint_items USING btree (tenant_id, checkpoint_id);


--
-- Name: ix_checkpoint_items_tenant_id_record_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_checkpoint_items_tenant_id_record_id ON public.checkpoint_items USING btree (tenant_id, record_id);


--
-- Name: ix_checkpoint_items_tenant_id_version_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_checkpoint_items_tenant_id_version_id ON public.checkpoint_items USING btree (tenant_id, version_id);


--
-- Name: ix_checkpoint_items_tenant_record_version; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_checkpoint_items_tenant_record_version ON public.checkpoint_items USING btree (tenant_id, record_id, version_id);


--
-- Name: ix_checkpoints_tenant_id_agent_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_checkpoints_tenant_id_agent_id ON public.checkpoints USING btree (tenant_id, agent_id);


--
-- Name: ix_documents_tenant_id_source_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_documents_tenant_id_source_id ON public.documents USING btree (tenant_id, source_id);


--
-- Name: ix_drift_observations_tenant_id_record_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_drift_observations_tenant_id_record_id ON public.drift_observations USING btree (tenant_id, record_id);


--
-- Name: ix_incident_evidence_tenant_id_incident_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_incident_evidence_tenant_id_incident_id ON public.incident_evidence USING btree (tenant_id, incident_id);


--
-- Name: ix_incidents_tenant_id_affected_record_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_incidents_tenant_id_affected_record_id ON public.incidents USING btree (tenant_id, affected_record_id);


--
-- Name: ix_incidents_tenant_id_agent_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_incidents_tenant_id_agent_id ON public.incidents USING btree (tenant_id, agent_id);


--
-- Name: ix_knowledge_relations_tenant_id_source_entity_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_knowledge_relations_tenant_id_source_entity_id ON public.knowledge_relations USING btree (tenant_id, source_entity_id);


--
-- Name: ix_knowledge_relations_tenant_id_target_entity_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_knowledge_relations_tenant_id_target_entity_id ON public.knowledge_relations USING btree (tenant_id, target_entity_id);


--
-- Name: ix_memory_records_tenant_id_agent_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_memory_records_tenant_id_agent_id ON public.memory_records USING btree (tenant_id, agent_id);


--
-- Name: ix_memory_records_tenant_id_source_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_memory_records_tenant_id_source_id ON public.memory_records USING btree (tenant_id, source_id);


--
-- Name: ix_memory_versions_tenant_id_record_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_memory_versions_tenant_id_record_id ON public.memory_versions USING btree (tenant_id, record_id);


--
-- Name: ix_policy_decisions_tenant_id_incident_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_policy_decisions_tenant_id_incident_id ON public.policy_decisions USING btree (tenant_id, incident_id);


--
-- Name: ix_quarantines_tenant_id_incident_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_quarantines_tenant_id_incident_id ON public.quarantines USING btree (tenant_id, incident_id);


--
-- Name: ix_quarantines_tenant_id_record_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_quarantines_tenant_id_record_id ON public.quarantines USING btree (tenant_id, record_id);


--
-- Name: ix_recovery_actions_tenant_id_plan_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_recovery_actions_tenant_id_plan_id ON public.recovery_actions USING btree (tenant_id, plan_id);


--
-- Name: ix_recovery_plans_tenant_id_checkpoint_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_recovery_plans_tenant_id_checkpoint_id ON public.recovery_plans USING btree (tenant_id, checkpoint_id);


--
-- Name: ix_recovery_plans_tenant_id_incident_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_recovery_plans_tenant_id_incident_id ON public.recovery_plans USING btree (tenant_id, incident_id);


--
-- Name: ix_recovery_plans_tenant_id_target_record_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_recovery_plans_tenant_id_target_record_id ON public.recovery_plans USING btree (tenant_id, target_record_id);


--
-- Name: ix_retrieval_events_tenant_id_agent_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_retrieval_events_tenant_id_agent_id ON public.retrieval_events USING btree (tenant_id, agent_id);


--
-- Name: ix_retrieval_events_tenant_id_record_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_retrieval_events_tenant_id_record_id ON public.retrieval_events USING btree (tenant_id, record_id);


--
-- Name: ix_tool_executions_tenant_id_decision_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_tool_executions_tenant_id_decision_id ON public.tool_executions USING btree (tenant_id, decision_id);


--
-- Name: ix_tool_proposals_tenant_id_agent_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_tool_proposals_tenant_id_agent_id ON public.tool_proposals USING btree (tenant_id, agent_id);


--
-- Name: ix_trace_spans_tenant_id_trace_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_trace_spans_tenant_id_trace_id ON public.trace_spans USING btree (tenant_id, trace_id);


--
-- Name: ix_traces_tenant_id_agent_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_traces_tenant_id_agent_id ON public.traces USING btree (tenant_id, agent_id);


--
-- Name: ix_transformations_tenant_id_input_record_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_transformations_tenant_id_input_record_id ON public.transformations USING btree (tenant_id, input_record_id);


--
-- Name: ix_transformations_tenant_id_output_record_id; Type: INDEX; Schema: public; Owner: amsc
--

CREATE INDEX ix_transformations_tenant_id_output_record_id ON public.transformations USING btree (tenant_id, output_record_id);


--
-- Name: audit_events trg_audit_events_chain; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_audit_events_chain BEFORE INSERT ON public.audit_events FOR EACH ROW EXECUTE FUNCTION public.amsc_audit_events_chain();


--
-- Name: audit_events trg_audit_events_no_truncate; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_audit_events_no_truncate BEFORE TRUNCATE ON public.audit_events FOR EACH STATEMENT EXECUTE FUNCTION public.prevent_audit_event_mutation();


--
-- Name: audit_events trg_audit_events_no_update_delete; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_audit_events_no_update_delete BEFORE DELETE OR UPDATE ON public.audit_events FOR EACH ROW EXECUTE FUNCTION public.prevent_audit_event_mutation();


--
-- Name: agent_tool_permissions trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.agent_tool_permissions FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: agent_versions trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.agent_versions FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: agents trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.agents FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: approvals trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.approvals FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: audit_events trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.audit_events FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: branches trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.branches FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: checkpoint_items trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.checkpoint_items FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: checkpoints trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.checkpoints FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: documents trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.documents FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: drift_observations trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.drift_observations FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: incident_evidence trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.incident_evidence FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: incidents trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.incidents FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: knowledge_entities trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.knowledge_entities FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: knowledge_relations trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.knowledge_relations FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: memberships trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.memberships FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: memory_records trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.memory_records FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: memory_versions trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.memory_versions FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: outbox_events trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.outbox_events FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: policy_decisions trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.policy_decisions FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: provenance_edges trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.provenance_edges FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: quarantines trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.quarantines FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: recovery_actions trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.recovery_actions FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: recovery_plans trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.recovery_plans FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: retrieval_events trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.retrieval_events FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: roles trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.roles FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: sources trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.sources FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: tool_executions trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.tool_executions FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: tool_proposals trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.tool_proposals FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: tool_registrations trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.tool_registrations FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: trace_spans trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.trace_spans FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: traces trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.traces FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: transformations trg_forbid_tenant_id_change; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_forbid_tenant_id_change BEFORE UPDATE OF tenant_id ON public.transformations FOR EACH ROW EXECUTE FUNCTION public.amsc_forbid_tenant_id_change();


--
-- Name: policy_decisions trg_policy_decisions_permanent; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_policy_decisions_permanent BEFORE DELETE OR UPDATE ON public.policy_decisions FOR EACH ROW EXECUTE FUNCTION public.amsc_policy_decisions_permanent();


--
-- Name: recovery_plans trg_protect_recovery_snapshot; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_protect_recovery_snapshot BEFORE DELETE OR UPDATE ON public.recovery_plans FOR EACH ROW EXECUTE FUNCTION public.amsc_protect_recovery_snapshot();


--
-- Name: recovery_actions trg_require_recovery_snapshot; Type: TRIGGER; Schema: public; Owner: amsc
--

CREATE TRIGGER trg_require_recovery_snapshot BEFORE INSERT OR UPDATE OF plan_id, tenant_id ON public.recovery_actions FOR EACH ROW EXECUTE FUNCTION public.amsc_require_recovery_snapshot();


--
-- Name: agent_tool_permissions fk_agent_tool_permissions_agent_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.agent_tool_permissions
    ADD CONSTRAINT fk_agent_tool_permissions_agent_id_tenant FOREIGN KEY (tenant_id, agent_id) REFERENCES public.agents(tenant_id, id) ON DELETE CASCADE;


--
-- Name: agent_tool_permissions fk_agent_tool_permissions_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.agent_tool_permissions
    ADD CONSTRAINT fk_agent_tool_permissions_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: agent_tool_permissions fk_agent_tool_permissions_tool_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.agent_tool_permissions
    ADD CONSTRAINT fk_agent_tool_permissions_tool_id_tenant FOREIGN KEY (tenant_id, tool_id) REFERENCES public.tool_registrations(tenant_id, id) ON DELETE CASCADE;


--
-- Name: agent_versions fk_agent_versions_agent_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.agent_versions
    ADD CONSTRAINT fk_agent_versions_agent_id_tenant FOREIGN KEY (tenant_id, agent_id) REFERENCES public.agents(tenant_id, id) ON DELETE CASCADE;


--
-- Name: agent_versions fk_agent_versions_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.agent_versions
    ADD CONSTRAINT fk_agent_versions_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: agents fk_agents_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT fk_agents_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: approvals fk_approvals_approver_user_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT fk_approvals_approver_user_id_tenant FOREIGN KEY (tenant_id, approver_user_id) REFERENCES public.memberships(tenant_id, user_id) ON DELETE RESTRICT;


--
-- Name: approvals fk_approvals_decision_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT fk_approvals_decision_id_tenant FOREIGN KEY (tenant_id, decision_id) REFERENCES public.policy_decisions(tenant_id, id) ON DELETE RESTRICT;


--
-- Name: approvals fk_approvals_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT fk_approvals_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE RESTRICT;


--
-- Name: audit_events fk_audit_events_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT fk_audit_events_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE RESTRICT;


--
-- Name: branches fk_branches_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT fk_branches_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: checkpoint_items fk_checkpoint_items_checkpoint_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.checkpoint_items
    ADD CONSTRAINT fk_checkpoint_items_checkpoint_id_tenant FOREIGN KEY (tenant_id, checkpoint_id) REFERENCES public.checkpoints(tenant_id, id) ON DELETE RESTRICT;


--
-- Name: checkpoint_items fk_checkpoint_items_record_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.checkpoint_items
    ADD CONSTRAINT fk_checkpoint_items_record_id_tenant FOREIGN KEY (tenant_id, record_id) REFERENCES public.memory_records(tenant_id, id) ON DELETE CASCADE;


--
-- Name: checkpoint_items fk_checkpoint_items_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.checkpoint_items
    ADD CONSTRAINT fk_checkpoint_items_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: checkpoint_items fk_checkpoint_items_version_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.checkpoint_items
    ADD CONSTRAINT fk_checkpoint_items_version_id_tenant FOREIGN KEY (tenant_id, version_id) REFERENCES public.memory_versions(tenant_id, id) ON DELETE CASCADE;


--
-- Name: checkpoint_items fk_checkpoint_items_version_matches_record; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.checkpoint_items
    ADD CONSTRAINT fk_checkpoint_items_version_matches_record FOREIGN KEY (tenant_id, record_id, version_id) REFERENCES public.memory_versions(tenant_id, record_id, id) ON DELETE CASCADE;


--
-- Name: checkpoints fk_checkpoints_agent_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.checkpoints
    ADD CONSTRAINT fk_checkpoints_agent_id_tenant FOREIGN KEY (tenant_id, agent_id) REFERENCES public.agents(tenant_id, id) ON DELETE SET NULL (agent_id);


--
-- Name: checkpoints fk_checkpoints_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.checkpoints
    ADD CONSTRAINT fk_checkpoints_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: documents fk_documents_source_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT fk_documents_source_id_tenant FOREIGN KEY (tenant_id, source_id) REFERENCES public.sources(tenant_id, id) ON DELETE CASCADE;


--
-- Name: documents fk_documents_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT fk_documents_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: drift_observations fk_drift_observations_record_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.drift_observations
    ADD CONSTRAINT fk_drift_observations_record_id_tenant FOREIGN KEY (tenant_id, record_id) REFERENCES public.memory_records(tenant_id, id) ON DELETE CASCADE;


--
-- Name: drift_observations fk_drift_observations_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.drift_observations
    ADD CONSTRAINT fk_drift_observations_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: incident_evidence fk_incident_evidence_incident_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.incident_evidence
    ADD CONSTRAINT fk_incident_evidence_incident_id_tenant FOREIGN KEY (tenant_id, incident_id) REFERENCES public.incidents(tenant_id, id) ON DELETE RESTRICT;


--
-- Name: incident_evidence fk_incident_evidence_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.incident_evidence
    ADD CONSTRAINT fk_incident_evidence_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE RESTRICT;


--
-- Name: incidents fk_incidents_affected_record_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT fk_incidents_affected_record_id_tenant FOREIGN KEY (tenant_id, affected_record_id) REFERENCES public.memory_records(tenant_id, id) ON DELETE SET NULL (affected_record_id);


--
-- Name: incidents fk_incidents_agent_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT fk_incidents_agent_id_tenant FOREIGN KEY (tenant_id, agent_id) REFERENCES public.agents(tenant_id, id) ON DELETE SET NULL (agent_id);


--
-- Name: incidents fk_incidents_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT fk_incidents_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE RESTRICT;


--
-- Name: knowledge_entities fk_knowledge_entities_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.knowledge_entities
    ADD CONSTRAINT fk_knowledge_entities_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: knowledge_relations fk_knowledge_relations_source_entity_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.knowledge_relations
    ADD CONSTRAINT fk_knowledge_relations_source_entity_id_tenant FOREIGN KEY (tenant_id, source_entity_id) REFERENCES public.knowledge_entities(tenant_id, id) ON DELETE CASCADE;


--
-- Name: knowledge_relations fk_knowledge_relations_target_entity_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.knowledge_relations
    ADD CONSTRAINT fk_knowledge_relations_target_entity_id_tenant FOREIGN KEY (tenant_id, target_entity_id) REFERENCES public.knowledge_entities(tenant_id, id) ON DELETE CASCADE;


--
-- Name: knowledge_relations fk_knowledge_relations_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.knowledge_relations
    ADD CONSTRAINT fk_knowledge_relations_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: memberships fk_memberships_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT fk_memberships_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: memberships fk_memberships_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT fk_memberships_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: memory_records fk_memory_records_agent_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memory_records
    ADD CONSTRAINT fk_memory_records_agent_id_tenant FOREIGN KEY (tenant_id, agent_id) REFERENCES public.agents(tenant_id, id) ON DELETE SET NULL (agent_id);


--
-- Name: memory_records fk_memory_records_source_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memory_records
    ADD CONSTRAINT fk_memory_records_source_id_tenant FOREIGN KEY (tenant_id, source_id) REFERENCES public.sources(tenant_id, id) ON DELETE SET NULL (source_id);


--
-- Name: memory_records fk_memory_records_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memory_records
    ADD CONSTRAINT fk_memory_records_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: memory_versions fk_memory_versions_record_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memory_versions
    ADD CONSTRAINT fk_memory_versions_record_id_tenant FOREIGN KEY (tenant_id, record_id) REFERENCES public.memory_records(tenant_id, id) ON DELETE CASCADE;


--
-- Name: memory_versions fk_memory_versions_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.memory_versions
    ADD CONSTRAINT fk_memory_versions_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: outbox_events fk_outbox_events_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.outbox_events
    ADD CONSTRAINT fk_outbox_events_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: policy_decisions fk_policy_decisions_incident_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.policy_decisions
    ADD CONSTRAINT fk_policy_decisions_incident_id_tenant FOREIGN KEY (tenant_id, incident_id) REFERENCES public.incidents(tenant_id, id) ON DELETE SET NULL (incident_id);


--
-- Name: policy_decisions fk_policy_decisions_proposal_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.policy_decisions
    ADD CONSTRAINT fk_policy_decisions_proposal_id_tenant FOREIGN KEY (tenant_id, proposal_id) REFERENCES public.tool_proposals(tenant_id, id) ON DELETE RESTRICT;


--
-- Name: policy_decisions fk_policy_decisions_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.policy_decisions
    ADD CONSTRAINT fk_policy_decisions_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE RESTRICT;


--
-- Name: provenance_edges fk_provenance_edges_from_record_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.provenance_edges
    ADD CONSTRAINT fk_provenance_edges_from_record_id_tenant FOREIGN KEY (tenant_id, from_record_id) REFERENCES public.memory_records(tenant_id, id) ON DELETE CASCADE;


--
-- Name: provenance_edges fk_provenance_edges_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.provenance_edges
    ADD CONSTRAINT fk_provenance_edges_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: provenance_edges fk_provenance_edges_to_record_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.provenance_edges
    ADD CONSTRAINT fk_provenance_edges_to_record_id_tenant FOREIGN KEY (tenant_id, to_record_id) REFERENCES public.memory_records(tenant_id, id) ON DELETE CASCADE;


--
-- Name: quarantines fk_quarantines_incident_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.quarantines
    ADD CONSTRAINT fk_quarantines_incident_id_tenant FOREIGN KEY (tenant_id, incident_id) REFERENCES public.incidents(tenant_id, id) ON DELETE SET NULL (incident_id);


--
-- Name: quarantines fk_quarantines_record_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.quarantines
    ADD CONSTRAINT fk_quarantines_record_id_tenant FOREIGN KEY (tenant_id, record_id) REFERENCES public.memory_records(tenant_id, id) ON DELETE CASCADE;


--
-- Name: quarantines fk_quarantines_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.quarantines
    ADD CONSTRAINT fk_quarantines_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: recovery_actions fk_recovery_actions_plan_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.recovery_actions
    ADD CONSTRAINT fk_recovery_actions_plan_id_tenant FOREIGN KEY (tenant_id, plan_id) REFERENCES public.recovery_plans(tenant_id, id) ON DELETE RESTRICT;


--
-- Name: recovery_actions fk_recovery_actions_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.recovery_actions
    ADD CONSTRAINT fk_recovery_actions_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: recovery_plans fk_recovery_plans_checkpoint_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.recovery_plans
    ADD CONSTRAINT fk_recovery_plans_checkpoint_id_tenant FOREIGN KEY (tenant_id, checkpoint_id) REFERENCES public.checkpoints(tenant_id, id) ON DELETE RESTRICT;


--
-- Name: recovery_plans fk_recovery_plans_incident_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.recovery_plans
    ADD CONSTRAINT fk_recovery_plans_incident_id_tenant FOREIGN KEY (tenant_id, incident_id) REFERENCES public.incidents(tenant_id, id) ON DELETE SET NULL (incident_id);


--
-- Name: recovery_plans fk_recovery_plans_target_record_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.recovery_plans
    ADD CONSTRAINT fk_recovery_plans_target_record_id_tenant FOREIGN KEY (tenant_id, target_record_id) REFERENCES public.memory_records(tenant_id, id) ON DELETE SET NULL (target_record_id);


--
-- Name: recovery_plans fk_recovery_plans_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.recovery_plans
    ADD CONSTRAINT fk_recovery_plans_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: retrieval_events fk_retrieval_events_agent_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.retrieval_events
    ADD CONSTRAINT fk_retrieval_events_agent_id_tenant FOREIGN KEY (tenant_id, agent_id) REFERENCES public.agents(tenant_id, id) ON DELETE CASCADE;


--
-- Name: retrieval_events fk_retrieval_events_record_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.retrieval_events
    ADD CONSTRAINT fk_retrieval_events_record_id_tenant FOREIGN KEY (tenant_id, record_id) REFERENCES public.memory_records(tenant_id, id) ON DELETE CASCADE;


--
-- Name: retrieval_events fk_retrieval_events_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.retrieval_events
    ADD CONSTRAINT fk_retrieval_events_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: role_permissions fk_role_permissions_permission_id_permissions; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT fk_role_permissions_permission_id_permissions FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions fk_role_permissions_role_id_roles; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT fk_role_permissions_role_id_roles FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: roles fk_roles_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT fk_roles_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: sources fk_sources_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT fk_sources_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tool_executions fk_tool_executions_decision_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_executions
    ADD CONSTRAINT fk_tool_executions_decision_id_tenant FOREIGN KEY (tenant_id, decision_id) REFERENCES public.policy_decisions(tenant_id, id) ON DELETE RESTRICT;


--
-- Name: tool_executions fk_tool_executions_decision_matches_proposal; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_executions
    ADD CONSTRAINT fk_tool_executions_decision_matches_proposal FOREIGN KEY (tenant_id, proposal_id, decision_id) REFERENCES public.policy_decisions(tenant_id, proposal_id, id) ON DELETE RESTRICT;


--
-- Name: tool_executions fk_tool_executions_proposal_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_executions
    ADD CONSTRAINT fk_tool_executions_proposal_id_tenant FOREIGN KEY (tenant_id, proposal_id) REFERENCES public.tool_proposals(tenant_id, id) ON DELETE RESTRICT;


--
-- Name: tool_executions fk_tool_executions_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_executions
    ADD CONSTRAINT fk_tool_executions_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE RESTRICT;


--
-- Name: tool_proposals fk_tool_proposals_agent_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_proposals
    ADD CONSTRAINT fk_tool_proposals_agent_id_tenant FOREIGN KEY (tenant_id, agent_id) REFERENCES public.agents(tenant_id, id) ON DELETE RESTRICT;


--
-- Name: tool_proposals fk_tool_proposals_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_proposals
    ADD CONSTRAINT fk_tool_proposals_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE RESTRICT;


--
-- Name: tool_registrations fk_tool_registrations_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.tool_registrations
    ADD CONSTRAINT fk_tool_registrations_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: trace_spans fk_trace_spans_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.trace_spans
    ADD CONSTRAINT fk_trace_spans_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: trace_spans fk_trace_spans_trace_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.trace_spans
    ADD CONSTRAINT fk_trace_spans_trace_id_tenant FOREIGN KEY (tenant_id, trace_id) REFERENCES public.traces(tenant_id, id) ON DELETE CASCADE;


--
-- Name: traces fk_traces_agent_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.traces
    ADD CONSTRAINT fk_traces_agent_id_tenant FOREIGN KEY (tenant_id, agent_id) REFERENCES public.agents(tenant_id, id) ON DELETE SET NULL (agent_id);


--
-- Name: traces fk_traces_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.traces
    ADD CONSTRAINT fk_traces_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: transformations fk_transformations_input_record_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.transformations
    ADD CONSTRAINT fk_transformations_input_record_id_tenant FOREIGN KEY (tenant_id, input_record_id) REFERENCES public.memory_records(tenant_id, id) ON DELETE CASCADE;


--
-- Name: transformations fk_transformations_output_record_id_tenant; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.transformations
    ADD CONSTRAINT fk_transformations_output_record_id_tenant FOREIGN KEY (tenant_id, output_record_id) REFERENCES public.memory_records(tenant_id, id) ON DELETE CASCADE;


--
-- Name: transformations fk_transformations_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: amsc
--

ALTER TABLE ONLY public.transformations
    ADD CONSTRAINT fk_transformations_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict FutJcNYUhAnBI2BjnXdrBOUvBdC2RftYhd1HlyA2IW9qcl8QdP6PSbvYMCjYPnk

